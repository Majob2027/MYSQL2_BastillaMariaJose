- # Filtro
  
- ## Maria Jose Bastilla Osorio - 1098668885
  
- ```
  Consultas #1
  
  Obtener los nombres de todos los actores y las películas en las
  que han actuado.
  
   select a.nombre , pe.titulo
  from actor a 
  inner join pelicula_actor p on a.id_actor = p.id_actor 
  inner join pelicula pe on p.id_pelicula = pe.id_pelicula;
  
  ```
  
  

```
Consulta #2

Listar todos los clientes y los almacenes donde están
registrados.



select nombre , id_almacen
from cliente;
```

```
Consulta #3

Encontrar todas las películas y sus respectivas categorías.

select p.titulo , c.nombre
from pelicula p
inner join pelicula_categoria pc on p.id_pelicula = pc.id_pelicula 
inner join categoria c on pc.id_categoria = c.id_categoria ;
```

```
Consulta #4

Listar los nombres de las ciudades junto con sus países.

select c.nombre , p.nombre 
from ciudad c 
inner join pais p on c.id_pais = p.id_pais;
```

```
Consulta #5

Obtener los detalles de los alquileres, incluyendo el cliente y el
empleado que gestionó el alquiler.

select a.* , c.nombre , e.nombre 
from alquiler a
inner join cliente c on a.id_cliente = c.id_cliente 
inner join empleado e on a.id_empleado = e.id_empleado;


```

```
Consulta #6

Encontrar todas las películas que se encuentran en un almacén
específico.


select p.titulo 
from pelicula p
inner join inventario i on p.id_pelicula = i.id_pelicula 
inner join almacen a on i.id_almacen = a.id_almacen
where a.id_almacen = 1;
```

```
Consulta #7

Listar los nombres y apellidos de los empleados junto con las
direcciones de los almacenes en los que trabajan.

select e.nombre , e.apellidos , d.direccion
from empleado e 
inner join almacen a on e.id_almacen = a.id_almacen 
inner join direccion d on a.id_direccion = d.id_direccion;
```

```
Consulta #8

Obtener una lista de pagos realizados, incluyendo el cliente, el
empleado que registró el pago y el alquiler correspondiente.

select p.id_pago , c.nombre , e.nombre , p.id_alquiler 
from pago p 
inner join cliente c on p.id_cliente = c.id_cliente 
inner join empleado e on p.id_empleado = e.id_empleado;
```

```
Consulta #9

Listar las películas y los idiomas en los que están disponibles.

select p.titulo , i.nombre
from pelicula p
inner join idioma i on p.id_idioma = i.id_idioma ;
```

```
Consulta #10

Encontrar todos los empleados y los almacenes que gestionan.

select nombre , id_almacen 
from empleado;
```

```
Consulta #11

Obtener los títulos de las películas que nunca han sido
alquiladas.

select p.titulo 
from pelicula p 
left join inventario i on p.id_pelicula = i.id_pelicula 
left join alquiler a on i.id_inventario = a.id_inventario
where a.id_alquiler is null;

```

```
Consulta #12

Listar los empleados que trabajan en el mismo almacén que el
empleado con id_empleado = 1.

SELECT e2.nombre 
AS empleado_nombre, e2.apellidos 
AS empleado_apellidos
FROM empleado e1
JOIN empleado e2 ON e1.id_almacen = e2.id_almacen
WHERE e1.id_empleado = 1 AND e2.id_empleado != 1;
```

```
Consulta #13

Encontrar el nombre de las ciudades que no tienen ningún
cliente registrado.

SELECT ci.nombre 
AS ciudad_nombre
FROM ciudad ci
LEFT JOIN direccion d ON ci.id_ciudad = d.id_ciudad
LEFT JOIN cliente c ON d.id_direccion = c.id_direccion
WHERE c.id_cliente IS NULL;
```

```
Consulta #14

Obtener los nombres y apellidos de los actores que han
participado en más de 10 películas.(having)

SELECT a.nombre 
AS actor_nombre, a.apellidos 
AS actor_apellidos, COUNT(pa.id_pelicula) 
AS numero_peliculas
FROM actor a
JOIN pelicula_actor pa ON a.id_actor = pa.id_actor
GROUP BY a.id_actor
HAVING COUNT(pa.id_pelicula) > 10;
```

```
Consulta #15

Encontrar los nombres y apellidos de los clientes que han
realizado un pago mayor a 100.

SELECT c.nombre 
AS cliente_nombre, c.apellidos 
AS cliente_apellidos
FROM cliente c
JOIN pago p ON c.id_cliente = p.id_cliente
WHERE p.cantidad > 100;
```

```
Consulta #16

Listar los títulos de las películas lanzadas en el mismo año que
la película con id_pelicula = 2.

SELECT p1.titulo 
AS pelicula_titulo
FROM pelicula p1
JOIN pelicula p2 ON YEAR(p1.anyo_lanzamiento) = YEAR(p2.anyo_lanzamiento)
WHERE p2.id_pelicula = 2;
```





