
use actividad1;

-- 1. Número de pacientes atendidos por cada médico 

SELECT m.nombre, COUNT(p.id_paciente) AS numero_pacientes 
FROM Medico m 
LEFT JOIN Pacientes p ON m.id_medico = p.id_medico_asignado 
GROUP BY m.id_medico, m.nombre; 
 

-- 2. Total de días de vacaciones planificadas y disfrutadas por cada empleado 

SELECT e.nombre, SUM(DATEDIFF(v.fecha_fin, v.fecha_inicio) + 1) AS dias_vacaciones 
FROM Empleados e 
JOIN Vacaciones v ON e.id_empleado = v.id_persona AND v.es_medico = FALSE 
GROUP BY e.id_empleado, e.nombre; 
 

-- 3. Médicos con mayor cantidad de horas de consulta en la semana 

SELECT m.nombre, SUM(TIMESTAMPDIFF(HOUR, h.hora_inicio, h.hora_fin)) AS horas_consulta_semanal 
FROM Medico m 
JOIN Horarios_Consulta h ON m.id_medico = h.id_medico 
GROUP BY m.id_medico, m.nombre 
ORDER BY horas_consulta_semanal DESC 
LIMIT 1; 
 

-- 4. Número de sustituciones realizadas por cada médico sustituto 


SELECT m.nombre, COUNT(f.id_fecha) AS numero_sustituciones 
FROM Medico m 
JOIN Fechas_Sustituciones f ON m.id_medico = f.id_medico_sustituto 
GROUP BY m.id_medico, m.nombre; 
 

-- 5. Número de médicos que están actualmente en sustitución 



SELECT COUNT(DISTINCT f.id_medico_sustituto) AS medicos_en_sustitucion 
FROM Fechas_Sustituciones f 
WHERE CURDATE() BETWEEN f.fecha_alta AND f.fecha_baja; 
 

-- 6. Horas totales de consulta por médico por día de la semana 



SELECT m.nombre, h.dia_semana, SUM(TIMESTAMPDIFF(HOUR, h.hora_inicio, h.hora_fin)) AS horas_totales 
FROM Medico m 
JOIN Horarios_Consulta h ON m.id_medico = h.id_medico 
GROUP BY m.id_medico, m.nombre, h.dia_semana; 
 

-- 7. Médico con mayor cantidad de pacientes asignados 

SELECT m.nombre, COUNT(p.id_paciente) AS numero_pacientes 
FROM Medico m 
LEFT JOIN Pacientes p ON m.id_medico = p.id_medico_asignado 
GROUP BY m.id_medico, m.nombre 
ORDER BY numero_pacientes DESC ; 
 

-- 8. Empleados con más de 10 días de vacaciones disfrutadas 
 

SELECT e.nombre, SUM(DATEDIFF(v.fecha_fin, v.fecha_inicio) + 1) AS dias_vacaciones 
FROM Empleados e 
JOIN Vacaciones v ON e.id_empleado = v.id_persona AND v.es_medico = FALSE 
GROUP BY e.id_empleado, e.nombre 
HAVING dias_vacaciones > 10; 
 

-- 9. Médicos que actualmente están realizando una sustitución 

SELECT m.nombre 
FROM Medico m 
JOIN Fechas_Sustituciones f ON m.id_medico = f.id_medico_sustituto 
WHERE CURDATE() BETWEEN f.fecha_alta AND f.fecha_baja; 
 
