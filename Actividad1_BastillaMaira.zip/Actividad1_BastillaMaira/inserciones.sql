use actividad1;
INSERT INTO Medico (nombre, direccion, telefono, poblacion, provincia, codigo_postal, nif, num_seguridad_social, num_colegiado, tipo_medico) VALUES
('Dr. Carlos López', 'Calle Mayor 1', '600123456', 'Madrid', 'Madrid', '28001', 'NC123456A', 'SS12345678A', 'NC890123A', 'titular'),
('Dr. Ana Ruiz', 'Avenida de la Paz 14', '600892123', 'Murcia', 'Murcia', '30001', 'NC123456B', 'SS12345678B', 'NC890123B', 'interino'),
('Dr. Pablo Sánchez', 'Calle Mayor 1', '600789012', 'Valladolid', 'Valladolid', '47001', 'NC123456C', 'SS12345678C', 'NC890123C', 'sustituto'),
('Dra. Elena Gómez', 'Plaza Mayor 27', '600123789', 'Santander', 'Cantabria', '39001', 'NC123456D', 'SS12345678D', 'NC890123D', 'titular'),
('Dr. Manuel Torres', 'Calle Luna 4', '600123567', 'Toledo', 'Toledo', '45001', 'NC123456E', 'SS12345678E', 'NC890123E', 'interino'),
('Dra. Silvia Ortiz', 'Avenida Sol 8', '600123456', 'Alicante', 'Alicante', '03001', 'NC123456F', 'SS12345678F', 'NC890123F', 'sustituto'),
('Dr. Roberto Moreno', 'Calle Estrella 6', '600789012', 'Córdoba', 'Córdoba', '14001', 'NC123456G', 'SS12345678G', 'NC890123G', 'titular'),
('Dra. Teresa Navarro', 'Calle Fuego 9', '600123456', 'Oviedo', 'Asturias', '33001', 'NC123456H', 'SS12345678H', 'NC890123H', 'interino'),
('Dr. Fernando Fernández', 'Calle Tierra 11', '600789012', 'Salamanca', 'Salamanca', '37001', 'NC123456I', 'SS12345678I', 'NC890123I', 'sustituto');


INSERT INTO Horarios_Consulta (id_medico, dia_semana, hora_inicio, hora_fin) VALUES
(1, 1, '08:00:00', '12:00:00'), -- Lunes
(1, 3, '08:00:00', '12:00:00'), -- Miércoles
(2, 2, '09:00:00', '13:00:00'), -- Martes
(2, 4, '09:00:00', '13:00:00'), -- Jueves
(3, 1, '10:00:00', '14:00:00'), -- Lunes
(3, 5, '10:00:00', '14:00:00'), -- Viernes
(4, 2, '08:00:00', '12:00:00'), -- Martes
(4, 4, '08:00:00', '12:00:00'), -- Jueves
(5, 3, '09:00:00', '13:00:00'), -- Miércoles
(5, 5, '09:00:00', '13:00:00'), -- Viernes
(6, 1, '08:00:00', '12:00:00'), -- Lunes
(6, 4, '08:00:00', '12:00:00'), -- Jueves
(7, 3, '10:00:00', '14:00:00'), -- Miércoles
(7, 5, '10:00:00', '14:00:00'), -- Viernes
(8, 2, '09:00:00', '13:00:00'), -- Martes
(8, 4, '09:00:00', '13:00:00'), -- Jueves
(9, 1, '08:00:00', '12:00:00'), -- Lunes
(9, 5, '08:00:00', '12:00:00'); -- Viernes

INSERT INTO Fechas_Sustituciones (id_medico_sustituto, fecha_alta, fecha_baja) VALUES
(3, '2024-01-01', '2024-01-15'), -- Dr. Pablo Sánchez
(6, '2024-02-01', '2024-02-15'), -- Dra. Silvia Ortiz
(9, '2024-03-01', '2024-03-15'); -- Dr. Fernando Fernández


INSERT INTO Empleados (nombre, direccion, telefono, poblacion, provincia, codigo_postal, nif, num_seguridad_social, tipo_empleado) VALUES
('Juan Pérez', 'Calle Mayor 10', '600123456', 'Madrid', 'Madrid', '28001', 'E123456A', 'ESS12345678A', 'ATS'),
('María García', 'Avenida Sol 20', '600567890', 'Barcelona', 'Barcelona', '08001', 'E123456B', 'ESS12345678B', 'ATS de zona'),
('Luis Martínez', 'Plaza Luna 15', '600345678', 'Sevilla', 'Sevilla', '41001', 'E123456C', 'ESS12345678C', 'auxiliar'),
('Ana Fernández', 'Calle Flor 5', '600456789', 'Valencia', 'Valencia', '46001', 'E123456D', 'ESS12345678D', 'celador'),
('Carlos López', 'Calle Olmo 3', '600789012', 'Bilbao', 'Vizcaya', '48001', 'E123456E', 'ESS12345678E', 'administrativo');

INSERT INTO Vacaciones (id_persona, es_medico, fecha_inicio, fecha_fin) VALUES
(1, TRUE, '2024-06-01', '2024-06-15'),
(2, FALSE, '2024-07-01', '2024-07-15'),
(3, TRUE, '2024-08-01', '2024-08-15'),
(4, FALSE, '2024-09-01', '2024-09-15'),
(5, TRUE, '2024-10-01', '2024-10-15');

INSERT INTO Pacientes (nombre, direccion, telefono, codigo_postal, nif, num_seguridad_social, id_medico_asignado) VALUES
('Paciente 1', 'Calle Paciente 1', '601234567', '28002', 'P123456A', 'PSS12345678A', 1), -- Dr. Carlos López
('Paciente 2', 'Calle Paciente 2', '601234568', '30002', 'P123456B', 'PSS12345678B', 2), -- Dr. Ana Ruiz
('Paciente 3', 'Calle Paciente 3', '601234569', '47002', 'P123456C', 'PSS12345678C', 3), -- Dr. Pablo Sánchez
('Paciente 4', 'Calle Paciente 4', '601234570', '39002', 'P123456D', 'PSS12345678D', 4), -- Dra. Elena Gómez
('Paciente 5', 'Calle Paciente 5', '601234571', '45002', 'P123456E', 'PSS12345678E', 5), -- Dr. Manuel Torres
('Paciente 6', 'Calle Paciente 6', '601234572', '03002', 'P123456F', 'PSS12345678F', 6), -- Dra. Silvia Ortiz
('Paciente 7', 'Calle Paciente 7', '601234573', '14002', 'P123456G', 'PSS12345678G', 7), -- Dr. Roberto Moreno
('Paciente 8', 'Calle Paciente 8', '601234574', '33002', 'P123456H', 'PSS12345678H', 8), -- Dra. Teresa Navarro
('Paciente 9', 'Calle Paciente 9', '601234575', '37002', 'P123456I', 'PSS12345678I', 9); -- Dr. Fernando Fernández
