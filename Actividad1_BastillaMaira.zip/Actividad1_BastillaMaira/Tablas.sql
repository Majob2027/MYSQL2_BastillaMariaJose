create database actividad1;

use actividad1 ;

 CREATE TABLE Medico ( 

    id_medico INT AUTO_INCREMENT PRIMARY KEY, 

    nombre VARCHAR(100) NOT NULL, 

    direccion VARCHAR(255), 

    telefono VARCHAR(15), 

    poblacion VARCHAR(100), 

    provincia VARCHAR(100), 

    codigo_postal VARCHAR(10), 

    nif VARCHAR(20) UNIQUE, 

    num_seguridad_social VARCHAR(20) UNIQUE, 

    num_colegiado VARCHAR(20) UNIQUE, 

    tipo_medico ENUM('titular', 'interino', 'sustituto') NOT NULL

); 

  

CREATE TABLE Horarios_Consulta ( 

    id_horario INT AUTO_INCREMENT PRIMARY KEY, 

    id_medico INT, 

    dia_semana TINYINT(1) CHECK (dia_semana BETWEEN 1 AND 7), 

    hora_inicio TIME, 

    hora_fin TIME, 

    FOREIGN KEY (id_medico) REFERENCES Medico(id_medico) 

); 

  

CREATE TABLE Fechas_Sustituciones ( 

    id_fecha INT AUTO_INCREMENT PRIMARY KEY, 

    id_medico_sustituto INT, 

    fecha_alta DATE, 

    fecha_baja DATE, 

    FOREIGN KEY (id_medico_sustituto) REFERENCES Medico(id_medico) 

); 

  

CREATE TABLE Empleados ( 

    id_empleado INT AUTO_INCREMENT PRIMARY KEY, 

    nombre VARCHAR(100) NOT NULL, 

    direccion VARCHAR(255), 

    telefono VARCHAR(15), 

    poblacion VARCHAR(100), 

    provincia VARCHAR(100), 

    codigo_postal VARCHAR(10), 

    nif VARCHAR(20) UNIQUE, 

    num_seguridad_social VARCHAR(20) UNIQUE, 

    tipo_empleado ENUM('ATS', 'ATS de zona', 'auxiliar', 'celador', 'administrativo') NOT NULL 

); 

  

CREATE TABLE Vacaciones ( 

    id_vacaciones INT AUTO_INCREMENT PRIMARY KEY, 

    id_persona INT, 

    es_medico BOOLEAN, 

    fecha_inicio DATE, 

    fecha_fin DATE, 

    FOREIGN KEY (id_persona) REFERENCES Empleados(id_empleado) 

); 

  

CREATE TABLE Pacientes ( 

    id_paciente INT AUTO_INCREMENT PRIMARY KEY, 

    nombre VARCHAR(100) NOT NULL, 

    direccion VARCHAR(255), 

    telefono VARCHAR(15), 

    codigo_postal VARCHAR(10), 

    nif VARCHAR(20) UNIQUE, 

    num_seguridad_social VARCHAR(20) UNIQUE, 

    id_medico_asignado INT, 

    FOREIGN KEY (id_medico_asignado) REFERENCES Medico(id_medico) 

); 